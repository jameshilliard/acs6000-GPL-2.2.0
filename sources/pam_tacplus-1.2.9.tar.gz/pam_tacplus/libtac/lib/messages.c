/*
 * Copyright 1997-2000 by Pawel Krawczyk <kravietz@ceti.pl>
 *
 * See http://www.ceti.com.pl/~kravietz/progs/tacacs.html
 * for details.
 *
 * messages.c  Various messages returned to user.
 */

char *system_err_msg="Authentication error, please contact administrator.";
char *protocol_err_msg="Protocol error.";
char *author_ok_msg="Service granted.";
char *author_fail_msg="Service not allowed.";
char *author_err_msg="Protocol error.";
