'**********************************************************************
'			SMS Messaging through VBasic
'
'			Alex Cooper - 12/02/2002
'			a.p.cooper@lancaster.ac.uk
'			    (until July 2002)
'			Lancaster University, UK
'**********************************************************************

This is the main part of the SMS code, repeated for each peice of data 
sent to the SMS server (destination, message, user, "send" command). 
It checks the server's feedback for the next prompt, instead of using 
specified timing.


    Do
        dummy = DoEvents()
        If Right(Text1.Text, 5) = "SMS> " Then
            strDest$ = "set dest = " + Text2.Text + Chr(10)
            Winsock1.SendData strDest$
            List2.AddItem "Destination Set"
            Exit Do
        End If
    Loop

This loops round until the following 'SMS> ' prompt is recieved from 
the server and displayed in Text1. When the prompt is found, the 
relevant data is sent to the server through the Winsock connection, 
the user is notified and the following loop sequence is begun for the 
following peice of data. Chr(10) sends a return character to the 
server.

Alex Cooper.