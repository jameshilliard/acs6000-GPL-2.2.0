/*==========================================================
 * Program : gsmts0338.h                   Project : smslink
 * Authors : Philippe Andersson.
 *           Fran�ois Baligant <francois@euronet.be>.
 * Date    : 18/10/01
 * Version : 0.01a
 * Notice  : (c) Les Ateliers du Heron, 1998 for Scitex Europe, S.A.
 * Comment : Header file for gsmts0338.c.
 *
 * Modification History :
 * - 0.01a (18/10/01) : Initial release.
 *========================================================*/

#ifndef _GSMTS0338_H
#define _GSMTS0338_H

#define GSMTS_VERSION	"0.04b"
#define GSMTS_DATE	"28/05/03"

/*----------------------------Tasks supported by the tool */
#define GSMTS_ENCODE	1
#define GSMTS_DECODE	2

/*==========================================================
 * Structure Declarations
 *========================================================*/

/*==========================================================
 * Function Declarations
 *========================================================*/

#endif                            /* #ifndef _GSMTS0338_H */

/*==========================================================
 * EOF : gsmts0338.h
 *===================*/
