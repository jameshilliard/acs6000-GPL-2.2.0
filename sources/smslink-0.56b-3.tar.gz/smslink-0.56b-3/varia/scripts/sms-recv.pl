#!/usr/bin/perl -w

    # Simple demo program - just sends an email with all the fields in it as
    # part of the body.
    #
    # Contributed by Andrew Worsley <epaanwo@asac.ericsson.se>.

    my ($device, $msgid, $fromgsm, $date, $time, $text) = @ARGV;
    if (@ARGV != 6) {
	print STDERR "Incorrect number of arguments found : ( @ARGV )\n";
    }
    my $debug = 1; # dump out all the args.
    my $cmd = "/usr/sbin/sendmail"; # where to find sendmail or equivalent 
    my $addr = "amw\@asac.ericsson.se"; # Address to send e-mail to
    my $i = 0;

    open(CMD, "|$cmd $addr") || die("Can't open $cmd");
    print CMD "To: $addr\n";
    print CMD "Subject: SMS from $fromgsm\n\n";

    print CMD "device='$device'\n";
    print CMD "msgid='$msgid'\n";
    print CMD "fromgsm='$fromgsm'\n";
    print CMD "date='$date'\n";
    print CMD "time='$time'\n";
    print CMD "text='$text'\n";

    if ($debug) {
	while (@ARGV > 0) {
	    $arg = shift(@ARGV);
	    print CMD "ARGV[$i] = '$arg'\n";
	    print "$arg\n" if $debug >= 2;
	    $i++;
	}
    }
    close(CMD) || die("sendmail failed");
    exit(0);
