-- Those SQL queries bring your MySQL backend from schema
-- version 3 to version 4 (required by SMSLink 0.56b).
--
-- Please review them before applying them to your installation.

ALTER TABLE inbox ADD processed ENUM('y','n') NOT NULL DEFAULT 'n';

ALTER TABLE outbox ADD priority INT UNSIGNED NOT NULL DEFAULT 3 AFTER qruns;

UPDATE schema SET schema_version = 4;
