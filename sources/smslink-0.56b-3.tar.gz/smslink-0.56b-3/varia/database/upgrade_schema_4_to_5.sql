-- Those SQL queries bring your MySQL backend from schema
-- version 4 to version 5 (required by SMSLink 0.56b-3).
--
-- Please review them before applying them to your installation.

RENAME TABLE schema TO dbschema;

UPDATE dbschema SET schema_version = 5;
