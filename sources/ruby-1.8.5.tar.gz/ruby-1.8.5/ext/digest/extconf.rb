# $RoughId: extconf.rb,v 1.6 2001/07/13 15:38:27 knu Exp $
# $Id: extconf.rb,v 1.1 2001/07/13 20:06:13 knu Exp $

require "mkmf"

create_makefile("digest")
