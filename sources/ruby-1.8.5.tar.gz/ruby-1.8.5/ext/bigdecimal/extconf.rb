require 'mkmf'
create_makefile('bigdecimal')
