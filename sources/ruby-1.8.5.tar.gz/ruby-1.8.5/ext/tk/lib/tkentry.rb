#
#   tkentry.rb - load tk/entry.rb
#
require 'tk/entry'
