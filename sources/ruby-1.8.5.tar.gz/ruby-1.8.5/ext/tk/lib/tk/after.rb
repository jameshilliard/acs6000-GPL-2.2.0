#
#   tk/after.rb : methods for Tcl/Tk after command
#
#   $Id: after.rb,v 1.1.2.1 2004/05/01 16:09:49 nagai Exp $
#
require 'tk/timer'
