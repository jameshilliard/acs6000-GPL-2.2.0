#
#   tktext.rb - load tk/text.rb
#
require 'tk/text'
