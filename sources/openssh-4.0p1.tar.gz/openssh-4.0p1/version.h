/* $OpenBSD: version.h,v 1.43 2005/03/08 23:49:48 djm Exp $ */

#define SSH_VERSION	"OpenSSH_4.0"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
