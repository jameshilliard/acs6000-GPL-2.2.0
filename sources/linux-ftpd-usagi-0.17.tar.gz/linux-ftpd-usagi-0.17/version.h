/*
 * String to embed in binaries to identify package
 */

char pkg[]="$NetKit: linux-ftpd-0.17 $";
