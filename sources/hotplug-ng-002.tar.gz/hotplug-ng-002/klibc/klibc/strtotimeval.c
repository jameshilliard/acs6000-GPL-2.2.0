#define NAME	 strtotimeval
#define TIMEX	 struct timeval
#define FSEC	 tv_usec
#define DECIMALS 6
#include "strtotimex.c"
