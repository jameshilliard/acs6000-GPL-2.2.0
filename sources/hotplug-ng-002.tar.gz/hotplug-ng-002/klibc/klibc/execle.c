/*
 * execle.c
 */

#define NAME execle
#define EXEC_P 0
#define EXEC_E 1
#include "exec_l.c"
