/*
 * arch/mips/include/machine/asm.h
 */

#ifndef _MACHINE_ASM_H
#define _MACHINE_ASM_H

#include <asm/regdef.h>
#include <asm/asm.h>

#endif /* _MACHINE_ASM_H */
