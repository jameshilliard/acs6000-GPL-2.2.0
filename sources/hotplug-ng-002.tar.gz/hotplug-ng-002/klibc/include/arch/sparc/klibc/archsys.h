/*
 * arch/sparc/include/klibc/archsys.h
 *
 * Architecture-specific syscall definitions
 */

#ifndef _KLIBC_ARCHSYS_H
#define _KLIBC_ARCHSYS_H

#endif /* _KLIBC_ARCHSYS_H */
