/*
 * netinet/in6.h
 */

#ifndef _NETINET_IN6_H
#define _NETINET_IN6_H

#include <linux/in6.h>

#endif /* _NETINET_IN6_H */
