/*
 * sys/utime.h
 */

#ifndef _SYS_UTIME_H
#define _SYS_UTIME_H

#include <linux/utime.h>

#endif /* _SYS_UTIME_H */
