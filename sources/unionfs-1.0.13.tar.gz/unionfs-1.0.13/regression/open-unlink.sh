#!/bin/sh
# TEST: Branches: b0,b1=ro and b0,b1
# TEST: open(a), unlink(a), receate(a), unlink(a)
# TEST:  at each point verify the contents of a using the original fd

source scaffold

function files {
cat <<FILES
d /n/lower
d /n/lower/b0
d /n/lower/b1
f /n/lower/b1/a
FILES
}

function afterfiles_ro {
cat <<FILES
d /n/lower
d /n/lower/b0
f /n/lower/b0/.wh.a
d /n/lower/b1
f /n/lower/b1/a
FILES
}

function afterfiles_rw {
cat <<FILES
d /n/lower
d /n/lower/b0
d /n/lower/b1
FILES
}


( files ) | create_hierarchy
mount_union "" /n/lower/b0 /n/lower/b1=ro
./progs/open-unlink $MOUNTPOINT/a
unmount_union
( afterfiles_ro ) | check_hierarchy /n/lower


echo "OK"
exit 0
