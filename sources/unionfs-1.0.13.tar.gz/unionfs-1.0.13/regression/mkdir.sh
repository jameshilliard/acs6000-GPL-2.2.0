#!/bin/sh

source scaffold

# initial directories
function directories {
cat <<FILES
d /n/lower
d /n/lower/b0
d /n/lower/b0/d1
d /n/lower/b0/d1/d2
d /n/lower/b0/d6
d /n/lower/b1
d /n/lower/b1/d5
d /n/lower/b1/d1
d /n/lower/b1/d1/d2
d /n/lower/b1/d1/d2/d3
f /n/lower/b1/d1/d2/d3/a
f /n/lower/b1/d1/d2/d3/b
f /n/lower/b1/d1/d2/d3/c
d /n/lower/b1/d1/d2/d3/d4
d /n/lower/b2
d /n/lower/b2/d5
d /n/lower/b2/d1
d /n/lower/b2/d1/d2
d /n/lower/b2/d1/d2/d3
f /n/lower/b2/d1/d2/d3/d
f /n/lower/b2/d1/d2/d3/e
f /n/lower/b2/d1/d2/d3/f
d /n/lower/b2/d1/d2/d3/d4

FILES
}

# initial set of files
function beforefiles {
cat <<FILES

f /n/lower/b0/d1/.wh.x

f /n/lower/b0/d1/d2/.wh.d3

FILES
}


function afterfiles_rw {
cat <<FILES
d /n/lower/b0/y

d /n/lower/b0/d1/x

d /n/lower/b0/d1/d2/d3

f /n/lower/b0/d1/d2/d3/.wh.__dir_opaque
f /n/lower/b0/d1/x/.wh.__dir_opaque
f /n/lower/b0/y/.wh.__dir_opaque

FILES
}



function afterfiles_ro {
cat <<FILES
d /n/lower/b0/y

d /n/lower/b0/d1/x

d /n/lower/b0/d1/d2/d3
f /n/lower/b0/d1/d2/d3/.wh.__dir_opaque
f /n/lower/b0/d1/x/.wh.__dir_opaque
f /n/lower/b0/y/.wh.__dir_opaque

FILES
}




##### simple tests
( directories ; beforefiles) | create_hierarchy

mount_union "" /n/lower/b0 /n/lower/b1 /n/lower/b2


mkdir $MOUNTPOINT/y
checktype $MOUNTPOINT/y 'd'
mkdir $MOUNTPOINT/d1/x
checktype $MOUNTPOINT/d1/x 'd'
mkdir $MOUNTPOINT/d1/d2/d3
checktype $MOUNTPOINT/d1/d2/d3 'd'
checktype $MOUNTPOINT/d1/d2/d3/d4 '-'

unmount_union
( directories ; afterfiles_rw )  | check_hierarchy /n/lower




#### simple tests
( directories ; beforefiles) | create_hierarchy

mount_union "" /n/lower/b0 /n/lower/b1=ro /n/lower/b2=ro

mkdir $MOUNTPOINT/y
checktype $MOUNTPOINT/y 'd'
mkdir $MOUNTPOINT/d1/x
checktype $MOUNTPOINT/d1/x 'd'
mkdir $MOUNTPOINT/d1/d2/d3
checktype $MOUNTPOINT/d1/d2/d3 'd'
checktype $MOUNTPOINT/d1/d2/d3/d4 '-'

unmount_union
( directories ; afterfiles_ro )  | check_hierarchy /n/lower

echo "OK"
exit 0
