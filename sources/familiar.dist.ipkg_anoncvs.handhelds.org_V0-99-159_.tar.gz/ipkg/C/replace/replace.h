#include "ipkg.h"

#ifndef HAVE_STRNDUP
char *strndup(const char *s, size_t size);
#endif
#ifndef HAVE_MKDTEMP
char *mkdtemp(char *template);
#endif
