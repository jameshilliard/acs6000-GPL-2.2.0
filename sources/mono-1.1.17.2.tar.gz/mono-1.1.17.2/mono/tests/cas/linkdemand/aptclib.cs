using System;

namespace Mono.Test {

	public class AptcLibrary {

		static public string Hello (string message)
		{
			return "Hello " + message;
		}
	}
}
