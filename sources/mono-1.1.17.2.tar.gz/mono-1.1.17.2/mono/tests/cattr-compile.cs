using System;

namespace Test {
	[CLSCompliant(false)]
	public class Test {
		[CLSCompliant(false)]
		public static int Main() {
			return 0;
		}
	}
}
