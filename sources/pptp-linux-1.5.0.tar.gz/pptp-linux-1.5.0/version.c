/* version.c ..... keep track of package version number. 
 *                 C. Scott Ananian <cananian@alumni.princeton.edu>
 *
 * $Id: version.c,v 1.2 2002/03/11 01:50:47 quozl Exp $
 */

#include "config.h"
const char * version = "pptp-linux version " PPTP_LINUX_VERSION;
