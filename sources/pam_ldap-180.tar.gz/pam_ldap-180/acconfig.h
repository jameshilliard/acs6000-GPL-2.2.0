/* Define to the number of arguments to ldap_set_rebindproc */
#undef LDAP_SET_REBIND_PROC_ARGS

/* define to the number of args to gethostbyname_r */
#undef GETHOSTBYNAME_R_ARGS

/* define to support PADL ypldapd locator */
#undef YPLDAPD


#define PAM_LDAP_PATH_CONF              "/etc/ldap.conf"
#define PAM_LDAP_PATH_ROOTPASSWD        "/etc/ldap.secret"

