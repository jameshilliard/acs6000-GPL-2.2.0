#define FCT in_dso2
#include "tst-tlsmod14a.c"
