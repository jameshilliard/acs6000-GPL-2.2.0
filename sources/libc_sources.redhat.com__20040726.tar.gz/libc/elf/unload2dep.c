extern void foo (void);

void
foo (void)
{
}
