extern const char *foo (void);

const char *
foo (void)
{
  return __FILE__;
}
