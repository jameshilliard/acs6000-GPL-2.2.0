extern int foo (void);

int some_var;


int
foo (void)
{
  return some_var;
}
