#define SINGLE_THREAD
#define __setregid pthread_setregid_np
#include <setregid.c>
