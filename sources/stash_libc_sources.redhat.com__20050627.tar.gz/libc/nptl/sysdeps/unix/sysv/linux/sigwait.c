#include <nptl/pthreadP.h>
#include "../../../../../sysdeps/unix/sysv/linux/sigwait.c"
