#include <nptl/sysdeps/i386/pthread_spin_init.c>
