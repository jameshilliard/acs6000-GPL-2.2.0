#define SINGLE_THREAD
#define seteuid pthread_seteuid_np
#include <seteuid.c>
