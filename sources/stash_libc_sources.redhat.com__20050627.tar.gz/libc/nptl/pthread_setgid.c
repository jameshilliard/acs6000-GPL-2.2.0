#define SINGLE_THREAD
#define __setgid pthread_setgid_np
#include <setgid.c>
