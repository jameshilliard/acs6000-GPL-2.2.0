
#ifndef SYSTEM_H
#define SYSTEM_H
namespace NWindows
{
	namespace NSystem
	{
		int GetNumberOfProcessors();
		UInt64 GetRamSize();
	}
}
#endif

