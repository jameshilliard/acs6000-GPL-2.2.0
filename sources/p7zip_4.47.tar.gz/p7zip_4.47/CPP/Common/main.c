#include "../../C/7zCrc.c"

int main(void) { return 0; }

