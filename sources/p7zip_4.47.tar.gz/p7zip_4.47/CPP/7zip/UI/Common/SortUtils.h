// SortUtils.h

#ifndef __SORTUTLS_H
#define __SORTUTLS_H

#include "Common/String.h"

void SortStringsToIndices(const UStringVector &strings, CIntVector &indices);
// void SortStrings(const UStringVector &src, UStringVector &dest);

#endif
