// Property.h

#ifndef __PROPERTY_H
#define __PROPERTY_H

#include "Common/String.h"

struct CProperty
{
  UString Name;
  UString Value;
};

#endif
