// Util/FilePathAutoRename.h

#ifndef __FILEPATHAUTORENAME_H
#define __FILEPATHAUTORENAME_H

#include "Common/String.h"

bool AutoRenamePath(UString &fullProcessedPath);

#endif
