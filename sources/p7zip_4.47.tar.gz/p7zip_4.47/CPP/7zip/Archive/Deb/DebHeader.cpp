// Archive/Deb/Header.h

#include "StdAfx.h"

#include "DebHeader.h"

namespace NArchive {
namespace NDeb {
namespace NHeader {

const char *kSignature  = "!<arch>\n";

}}}
