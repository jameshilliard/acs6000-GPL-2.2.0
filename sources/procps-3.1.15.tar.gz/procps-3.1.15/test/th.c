#include <unistd.h>
#include <pthread.h>

void *hanger(void *vp){
  (void)vp;
  for(;;) pause();
}

int main(int argc, char *argv[]){
  pthread_t thread;
  (void)argc;
  (void)argv;
  pthread_create(&thread, NULL, hanger, NULL);
  hanger(NULL);
  return 0; // keep gcc happy
}
