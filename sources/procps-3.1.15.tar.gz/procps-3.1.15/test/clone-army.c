// ps fTo sess,pgid,pid,tty,ppid,tpgid,args -C a.out

#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
//#include <sys/stat.h>
//#include <fcntl.h>
//#include <stdlib.h>
#include <stdio.h>
#include <sched.h>

#if 0
#define CLONE_VM             0x00000100 // set if VM shared between processes
#define CLONE_FS             0x00000200 // set if fs info shared between processes
#define CLONE_FILES          0x00000400 // set if open files shared between processes
#define CLONE_SIGHAND        0x00000800 // set if signal handlers and blocked signals shared
#define CLONE_IDLETASK       0x00001000 // set if new pid should be 0 (kernel only)*/
#define CLONE_PTRACE         0x00002000 // set if we want to let tracing continue on the child too
#define CLONE_VFORK          0x00004000 // set if the parent wants the child to wake it up on mm_release
#define CLONE_PARENT         0x00008000 // set if we want to have the same parent as the cloner
#define CLONE_THREAD         0x00010000 // Same thread group?
#define CLONE_NEWNS          0x00020000 // New namespace group?
#define CLONE_SYSVSEM        0x00040000 // share system V SEM_UNDO semantics
#define CLONE_SETTLS         0x00080000 // create a new TLS for the child
#define CLONE_PARENT_SETTID  0x00100000 // set the TID in the parent
#define CLONE_CHILD_CLEARTID 0x00200000 // clear the TID in the child
#define CLONE_DETACHED       0x00400000 // parent wants no child-exit signal
#define CLONE_UNTRACED       0x00800000 // set if the tracing process can't force CLONE_PTRACE on this clone
#define CLONE_CHILD_SETTID   0x01000000 // set the TID in the child
#define CLONE_STOPPED        0x02000000 // Start in stopped state
#endif

#ifndef CLONE_THREAD
#define CLONE_THREAD         0x00010000
#endif
#ifndef CLONE_DETACHED
#define CLONE_DETACHED       0x00400000
#endif


// interesting: VM FS FILES SIGHAND PARENT THREAD SYSVSEM DETACHED

//#define FLAGS (CLONE_PARENT|CLONE_FS|CLONE_FILES|CLONE_SIGHAND|CLONE_VM|CLONE_THREAD|CLONE_SYSVSEM)
#define FLAGS (CLONE_FS|CLONE_FILES|CLONE_SIGHAND|CLONE_VM|CLONE_THREAD|CLONE_DETACHED)

// Don't cause rejection: FS FILES SYSVSEM PARENT
// Do cause rejection:

static void printflags(int pass, unsigned flags){
  printf(
    "%s %08x %s %s %s %s\n",
    pass?"pass":"FAIL",
    flags,
    (flags&CLONE_THREAD) ? "THREAD" : "______",
    (flags&CLONE_DETACHED) ? "DETACHED" : "________",
    (flags&CLONE_SIGHAND) ? "SIGHAND" : "_______",
    (flags&CLONE_SIGHAND) ? "VM" : "__"
  );
}

static unsigned genflags(unsigned flags){
  return (
    (flags&0x08) ? 0 : CLONE_THREAD
    )|(
    (flags&0x04) ? 0 : CLONE_DETACHED
    )|(
    (flags&0x02) ? 0 : CLONE_SIGHAND
    )|(
    (flags&0x01) ? 0 : CLONE_VM
  );
}

//static pid_t one;

//static void die(int signo){
//  (void)signo;
//  _exit(0);
//}

//static void sigchld_handler(int signo){
//  (void)signo;
//  kill(one,SIGHUP);          // kill parent
//}

static int clone_fn(void *vp){
  for(;;) pause();
}

static long clone_stack_data[2048];
#ifdef __hppa__
static long *clone_stack = &clone_stack_data[0];
#else
static long *clone_stack = &clone_stack_data[2048];
#endif

int main(int argc, char *argv[]){
  unsigned u;
  pid_t minime;
  (void)argc;
  (void)argv;

//  one = getpid();
//  signal(SIGHUP,die);
//  if(fork()) hang();    // parent later killed as readyness signal

  u = 16;

  while(u--){
    unsigned f = genflags(u);
    minime = clone(clone_fn, clone_stack, f, "arg");

    printflags(minime!=-1, f);
//    if(minime==-1){
//      perror("no clone");
//      _exit(8);
//    }

//    printf("%d begat %d\n",getpid(),minime);
  }


//  kill(one,SIGHUP); // let the shell know we're ready

//  clone_fn();

  return 0;
}
