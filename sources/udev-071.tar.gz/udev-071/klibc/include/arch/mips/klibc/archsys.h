/*
 * arch/mips/include/klibc/archsys.h
 *
 * Architecture-specific syscall definitions
 */

#ifndef _KLIBC_ARCHSYS_H
#define _KLIBC_ARCHSYS_H

/* No special syscall definitions for this architecture */

#endif /* _KLIBC_ARCHSYS_H */
