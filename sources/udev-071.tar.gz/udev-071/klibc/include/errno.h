/*
 * errno.h
 */

#include <klibc/extern.h>
#include <asm/errno.h>

__extern int errno;
