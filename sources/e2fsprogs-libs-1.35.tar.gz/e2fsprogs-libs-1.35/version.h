/*
 * version.h --- controls the version number printed by the e2fs
 * programs.
 * 
 * Copyright 1995, 1996, 1997, 1998, 1999, 2000, 2001 by Theodore
 * Ts'o.  This file may be redistributed under the GNU Public License.
 */

#define E2FSPROGS_VERSION "1.35"
#define E2FSPROGS_DATE "28-Feb-2004"
