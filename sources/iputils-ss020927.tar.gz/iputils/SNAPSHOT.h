static char SNAPSHOT[] = "020927";
