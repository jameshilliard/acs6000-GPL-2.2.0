#include <sunrpc/rpc/auth_unix.h>

extern bool_t xdr_authunix_parms_internal (XDR *__xdrs,
					   struct authunix_parms *__p);
