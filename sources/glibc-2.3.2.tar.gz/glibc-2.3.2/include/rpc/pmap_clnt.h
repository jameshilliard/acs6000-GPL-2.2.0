#ifndef _RPC_PMAP_CLNT_H
# include <sunrpc/rpc/pmap_clnt.h>

libc_hidden_proto (pmap_getport)
libc_hidden_proto (pmap_set)
libc_hidden_proto (pmap_unset)

#endif
