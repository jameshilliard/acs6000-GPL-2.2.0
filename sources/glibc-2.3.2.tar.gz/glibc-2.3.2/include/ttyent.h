#ifndef	_TTYENT_H
# include <misc/ttyent.h>

libc_hidden_proto (getttyent)
libc_hidden_proto (setttyent)
libc_hidden_proto (endttyent)

#endif
