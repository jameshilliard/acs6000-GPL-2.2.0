#ifndef _MCHECK_H

#include <malloc/mcheck.h>

libc_hidden_proto (mcheck)
libc_hidden_proto (mcheck_check_all)

#endif
