#include <misc/sys/syslog.h>

libc_hidden_proto (syslog)
libc_hidden_proto (vsyslog)
