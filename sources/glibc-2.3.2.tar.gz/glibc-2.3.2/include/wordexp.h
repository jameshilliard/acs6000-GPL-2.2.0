#ifndef _WORDEXP_H

#include <posix/wordexp.h>

libc_hidden_proto (wordfree)

#endif
