/* Stubby version of intr-msg.h. */

/* This file must be written in machine-dependent form for each hurd port.
   and define the following:

   INTR_MSG_TRAP
   INTR_MSG_BACK_OUT
   SYSCALL_EXAMINE
   struct mach_msg_trap_args
   MSG_EXAMINE

   See sysdeps/mach/hurd/i386/intr-msg.h for an example. */


#error Could not find machine-dependent intr-msg.h file.
