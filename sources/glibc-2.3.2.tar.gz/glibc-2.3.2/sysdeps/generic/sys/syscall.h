/* For Unix-like systems, this file should contain definitions
   of macros SYS_call for each system call, giving the call numbers.  */
