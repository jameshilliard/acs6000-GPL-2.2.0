/* There has to be an architecture specific version of this file.  */
#error "architecture-specific version of <dl-tls.h> missing"
