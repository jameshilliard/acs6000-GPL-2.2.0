/* No architecture specific definitions.  */
