// DTD_Manager.cpp,v 1.3 2002/02/14 06:28:57 nanbor Exp

#include "ACEXML/common/DTD_Manager.h"

ACEXML_DTD_Manager::~ACEXML_DTD_Manager ()
{

}
