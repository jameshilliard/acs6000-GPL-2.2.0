#include "DTDHandler.h"


ACE_RCSID (common,
           DTDHandler,
           "DTDHandler.cpp,v 1.1 2005/04/20 16:22:53 ossama Exp")


ACEXML_DTDHandler::~ACEXML_DTDHandler (void)
{
}
