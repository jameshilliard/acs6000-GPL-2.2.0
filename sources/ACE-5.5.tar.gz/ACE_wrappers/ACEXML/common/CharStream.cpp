// -*- C++ -*-  CharStream.cpp,v 1.3 2002/02/14 06:28:57 nanbor Exp

#include "ACEXML/common/CharStream.h"

ACEXML_CharStream::~ACEXML_CharStream (void)
{
}
