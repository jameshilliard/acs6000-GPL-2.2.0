#include "Locator.h"


ACE_RCSID (common,
           Locator,
           "Locator.cpp,v 1.1 2005/04/20 16:22:53 ossama Exp")


ACEXML_Locator::~ACEXML_Locator (void)
{
}
