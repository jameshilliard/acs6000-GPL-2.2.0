// Validator.cpp,v 1.3 2002/02/14 06:28:57 nanbor Exp

#include "ACEXML/common/Validator.h"

ACEXML_Validator::~ACEXML_Validator ()
{

}
