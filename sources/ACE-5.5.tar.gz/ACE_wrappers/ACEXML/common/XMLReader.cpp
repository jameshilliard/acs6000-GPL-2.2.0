#include "XMLReader.h"


ACE_RCSID (common,
           XMLReader,
           "XMLReader.cpp,v 1.1 2005/04/20 16:22:53 ossama Exp")


ACEXML_XMLReader::~ACEXML_XMLReader (void)
{
}
