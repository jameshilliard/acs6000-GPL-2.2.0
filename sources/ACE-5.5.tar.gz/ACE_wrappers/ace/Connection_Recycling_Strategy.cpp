#include "ace/Connection_Recycling_Strategy.h"


ACE_RCSID(ace, Connection_Recycling_Strategy, "Connection_Recycling_Strategy.cpp,v 4.3 2005/10/28 16:14:52 ossama Exp")


ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_Connection_Recycling_Strategy::~ACE_Connection_Recycling_Strategy (void)
{
}

ACE_END_VERSIONED_NAMESPACE_DECL
