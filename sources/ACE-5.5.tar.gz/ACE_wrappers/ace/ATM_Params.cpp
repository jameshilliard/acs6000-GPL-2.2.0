// ATM_Params.cpp,v 4.7 2005/10/28 16:14:51 ossama Exp

#include "ace/ATM_Params.h"

#if defined (ACE_HAS_ATM)

ACE_RCSID(ace, ATM_Params, "ATM_Params.cpp,v 4.7 2005/10/28 16:14:51 ossama Exp")

#if !defined (__ACE_INLINE__)
#include "ace/ATM_Params.inl"
#endif /* __ACE_INLINE__ */

ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_ALLOC_HOOK_DEFINE(ACE_ATM_Params)

ACE_END_VERSIONED_NAMESPACE_DECL

#endif /* ACE_HAS_ATM */

