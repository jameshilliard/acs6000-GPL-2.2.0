// Log_Msg_Backend.cpp,v 4.2 2005/10/28 16:14:53 ossama Exp

#include "ace/Log_Msg_Backend.h"

ACE_RCSID(ace, Log_Msg_Backend, "Log_Msg_Backend.cpp,v 4.2 2005/10/28 16:14:53 ossama Exp")


ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_Log_Msg_Backend::~ACE_Log_Msg_Backend (void)
{
}

ACE_END_VERSIONED_NAMESPACE_DECL
