// Active_Map_Manager.cpp,v 4.4 2005/10/28 16:14:51 ossama Exp

#include "ace/Active_Map_Manager.h"

ACE_RCSID(ace, Active_Map_Manager, "Active_Map_Manager.cpp,v 4.4 2005/10/28 16:14:51 ossama Exp")

#if !defined (__ACE_INLINE__)
#include "ace/Active_Map_Manager.inl"
#endif /* __ACE_INLINE__ */
