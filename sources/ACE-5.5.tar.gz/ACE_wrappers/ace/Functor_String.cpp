#include "ace/Functor_String.h"

#if !defined (__ACE_INLINE__)
#include "ace/Functor_String.inl"
#endif /* __ACE_INLINE__ */

ACE_RCSID(ace, Functor, "Functor_String.cpp,v 4.2 2004/03/29 05:46:44 bala Exp")
