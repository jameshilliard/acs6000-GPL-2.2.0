/* -*-c-*-
 * pam_krb5.c
 * PAM-kerberos5 module, PAM interface.  
 * Naomaru Itoi <itoi@eecs.umich.edu>, 1997/6/23. 
 * Copyright information is at the end of the file.  
 */

#include <sys/types.h>
#include <sys/param.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <syslog.h>
#ifndef __USE_MISC
#define __USE_MISC      /* for get/set/endpwent */
#endif
#include <pwd.h>
#include <time.h>	/* for time() */
#include <fcntl.h>

#ifndef _SVID_SOURCE
#define _SVID_SOURCE
#endif
#ifndef __USE_BSD
#define __USE_BSD
#endif
#include <sys/time.h>
#include <unistd.h>

/* indicate the following groups are defined */

#define PAM_SM_AUTH
#define PAM_SM_SESSION
#define PAM_SM_PASSWORD

#include <security/pam_modules.h>

#ifndef LINUX 
#include <security/pam_appl.h>
#endif  /* LINUX */

#include <netinet/in.h>

/* NI, for kerberos 5 */
#include <kadm5/admin.h>
#include <krb5.h>
#include <kpasswd_strings.h>
#define string_text error_message
#define initialize_kpasswd_strings initialize_kpws_error_table
#define KRB5CCNAME_ROOT "/tmp/krb5cc"

/*#ifdef DEBUG*/
#define D(x) { \
  _debug_pam("[%s:%s(%d)] ", __FILE__, __FUNCTION__, __LINE__) ; \
  _debug_pam x ; \
}
/*
#else
#define D(x)
#endif
*/

#include "./support.-c"

/*
 * PAM framework looks for these entry-points to pass control to the
 * authentication module.
 */

#include "./pam_krb5_auth.-c"

PAM_EXTERN int pam_sm_authenticate(pam_handle_t *pamh, 
				   int flags,
				   int argc, 
				   const char **argv)
{
     unsigned int ctrl;
     int retval;
     D(("called.\n"));
     ctrl = set_ctrl(flags, argc, argv);
     retval = _krb5_auth( pamh, ctrl );
     return retval;
}

PAM_EXTERN int pam_sm_setcred(pam_handle_t *pamh, 
			      int flags,
			      int argc, 
			      const char **argv)
{
     unsigned int ctrl;
     D(("called.\n"));
     ctrl = set_ctrl(flags, argc, argv);
     return _krb5_set_credentials(pamh, flags) ;
}

/*
 * PAM framework looks for these entry-points to pass control to the
 * session module.
 */
/* include session management for krb-5 */

#include "./pam_krb5_sess.-c"

PAM_EXTERN int pam_sm_open_session(pam_handle_t *pamh, int flags,
				   int argc, const char **argv)
{
     unsigned int ctrl;

     D(("called.\n"));
     ctrl = set_ctrl(flags, argc, argv);
     return _krb5_open_session(pamh, ctrl);
}

PAM_EXTERN int pam_sm_close_session(pam_handle_t *pamh, int flags,
				    int argc, const char **argv)
{
     unsigned int ctrl;

     D(("called.\n"));
     ctrl = set_ctrl(flags, argc, argv);
     return _krb5_close_session(pamh, ctrl);
}

/*
 * PAM framework looks for these entry-points to pass control to the
 * password changing module.
 */

/* include krb5_passwd module */
#include "./pam_krb5_passwd.-c"

PAM_EXTERN int pam_sm_chauthtok(pam_handle_t *pamh, int flags,
				int argc, const char **argv)
{
     unsigned int ctrl;
     int retval;
     D(("called.\n"));
     ctrl = set_ctrl(flags, argc, argv);
     retval = _krb5_chauthtok(pamh, ctrl);
     return retval;
}

/* static module data */

#ifdef PAM_STATIC
struct pam_module _pam_krb5_modstruct = {
     "pam_krb5",
     pam_sm_authenticate,
     pam_sm_setcred,
     NULL,
     pam_sm_open_session,
     pam_sm_close_session,
     pam_sm_chauthtok
};

#endif


/*--------------------------------------------------------------------------
COPYRIGHT (c)  1997
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE
THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR ANY PURPOSE, SO LONG AS THE NAME
OF THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.  IF THE ABOVE COPYRIGHT NOTICE OR ANY OTHER
IDENTIFICATION OF THE UNIVERSITY OF MICHIGAN IS INCLUDED IN ANY COPY OF ANY
PORTION OF THIS SOFTWARE, THEN THE DISCLAIMER BELOW MUST ALSO BE INCLUDED.

THE SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF
MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT WARRANTY BY THE
UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING
WITHOUT LIMITATION THE IMPLIED WARRANTIES OF MERCHANTABITILY AND FITNESS FOR A
PARTICULAR PURPOSE.  THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL NOT BE
LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR
CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN
CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER
ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
--------------------------------------------------------------------------*/
