#ifndef PWDB_DECNIS_PUBLIC_H
#define PWDB_DECNIS_PUBLIC_H

/* decnis function prototypes */
 
/* DECNIS PASSWD 
 * - only pure decnis functions are working at this moment
 * - the commented ones need access to the /etc/passwd entries,
 *   we have to build the interface first
 */
struct __pwdb_passwd * __pwdb_decnis_getpwuid (uid_t);
struct __pwdb_passwd * __pwdb_decnis_getpwnam (const char *);
int __pwdb_decnis_update (const char *, const struct __pwdb_passwd *);
struct __pwdb_passwd  *__pwdbNIS_check_password_adjunct(char *nisdomain, 
							char *tname, char *nisval);
int __pwdbNIS_shadow_passwd_merge(char *in_str, char *shadow, char *scratch, int shadow_type);
/* struct __pwdb_passwd * __pwdb_decnis_sgetpwent (char *); */
/* struct __pwdb_passwd * __pwdb_decnis_fgetpwent (FILE *); */
/* struct __pwdb_passwd * __pwdb_decnis_getpwent (void);    */
/* void __pwdb_decnis_setpwent (void);                      */
/* void __pwdb_decnis_endpwent (void);                      */

/* decnis GROUP 
 * - only pure decnis functions are working at this moment
 * - the commented ones need access to the /etc/group entries,
 *   we have to build the interface first
 */
struct __pwdb_group * __pwdb_decnis_getgrgid (gid_t);
struct __pwdb_group * __pwdb_decnis_getgrnam (const char *);
/* struct __pwdb_group * __pwdb_decnis_fgetgrent (FILE *); */
/* struct __pwdb_group * __pwdb_decnis_getgrent (void); */
/* void __pwdb_decnis_setgrent (void); */
/* void __pwdb_decnis_endgrent (void); */

#endif /* PWDB_DECNIS_PUBLIC_H */
