
#ifndef PWDB_INTERFACE_DECNIS
#define PWDB_INTERFACE_DECNIS

/*
 * user functions
 */

#include "decnis/user.c"
static struct _pwdb_module _pwdb_decnis_struct = {
    PWDB_DECNIS,
    "decnis",
    "user",
    _pwdb_decnis_locate,
    _pwdb_decnis_request,
    _pwdb_decnis_replace,
    _pwdb_decnis_delete,
    _pwdb_decnis_support,
    _pwdb_decnis_flags
};

/* 
 * group functions
 */

#include "decnis/group.c"
static struct _pwdb_module _pwdb_decnis_g_struct = {
    PWDB_DECNIS,
    "decnis",
    "group",
    _pwdb_decnis_glocate,
    _pwdb_decnis_grequest,
    _pwdb_decnis_greplace,
    _pwdb_decnis_gdelete,
    _pwdb_decnis_gsupport,
    _pwdb_decnis_gflags
};

#endif /* PWDB_INTERFACE_decnis */

