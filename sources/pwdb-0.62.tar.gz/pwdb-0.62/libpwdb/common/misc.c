/*
 * $Id: misc.c,v 1.1.1.1 1998/10/06 20:58:43 gafton Exp $
 *
 * $Log: misc.c,v $
 * Revision 1.1.1.1  1998/10/06 20:58:43  gafton
 * Imported version 0 into the current tree
 *
 */

/*
 * this is the enevitable file that contains all the utility things that
 * are needed by the library
 */

#include "../_pwdb_internal.h"

char *__pwdb_strdup(const char *x)
{
     if (x != NULL) {
	  char *s = (char *) malloc(strlen(x)+1);
	  if (s) {
	       strcpy(s,x);
	  }
	  return s;
     } else
	  return NULL;
}
